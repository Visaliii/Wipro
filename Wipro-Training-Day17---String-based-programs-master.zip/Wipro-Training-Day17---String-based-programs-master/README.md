Wipro TalentNext PBL

Topics Covered String based programs 

The “Nambiar Number” Generator
https://tests.mettl.com/authenticateKey/7db6c8a4

User ID Generation
https://tests.mettl.com/authenticateKey/592740f3

Message controlled Robot movement
https://tests.mettl.com/authenticateKey/aedcc3a6